﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TASK_3.Models;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using TASK_3.Repository;

namespace Task_3.Repository
{
    public class RegistrationRepo : IRegistration
    {
        public async Task<RegistrationDet> createNewRegistration(RegistrationDet rd)
        {
            DB4Context ctx = new DB4Context();
            ctx.Add(rd);
            await ctx.SaveChangesAsync();
            return rd;
        }

        public async Task deleteRegistration(int id)
        {
            DB4Context ctx = new DB4Context();
            var query = ctx.RegistrationDet.Find(id);
            ctx.RegistrationDet.Remove(query);
            await ctx.SaveChangesAsync();
        }

        public async Task<IEnumerable<RegistrationDet>> getAllDetails()
        {
           DB4Context ctx = new DB4Context();
            return await ctx.RegistrationDet.Select(i => i).ToListAsync();
        }

        public async Task<RegistrationDet> getDetailsById(int id)
        {
            DB4Context ctx = new DB4Context();
            return await ctx.RegistrationDet.FindAsync(id);
        }

        public async Task updateRegistration(int id, RegistrationDet rd)
        {
            DB4Context ctx = new DB4Context();
            ctx.Entry(rd).State = EntityState.Modified;
            await ctx.SaveChangesAsync();
        }
    }
}
