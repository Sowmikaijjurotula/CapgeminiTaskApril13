﻿using System.Threading.Tasks;
using System.Collections.Generic;
using TASK_3.Models;
namespace TASK_3.Repository
{
    public interface IRegistration
    {
        Task<IEnumerable<RegistrationDet>> getAllDetails();
        Task<RegistrationDet> getDetailsById(int id);
        Task<RegistrationDet> createNewRegistration(RegistrationDet rd);
        Task updateRegistration(int id, RegistrationDet rd);
        Task deleteRegistration(int id);


    }
}
